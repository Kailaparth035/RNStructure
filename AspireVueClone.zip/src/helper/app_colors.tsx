export default {
  primaryColor: '#A678EC',
  secondryColor: '#57ABE7',
  White: '#FFFFFF',
  Black: '#000000',
  Background: '#E7E8F4',
  lightPurple: '#babbd0',
  purple: '#6F6481',
  brown: '#483228',
  loginInpute: 'rgba(16,1,1,0.39)',
  activeTabIcon: '#b1b1e1',
  borderColor: '#F1EAE2',
  deletPostText: '#515c6f',
};
