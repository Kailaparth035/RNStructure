export default {
  Login: 'Login',
  DashBoard: 'Dashboard',
  Splash: 'Splash',
  UserListScreen: 'UserListScreen',
};
