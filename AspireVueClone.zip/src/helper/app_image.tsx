const images = '../assets/images/';

export default {
  splashLogo: require(images + 'splash_logo.png'),
  loginTopBg: require(images + 'login_top_bg.png'),
};
