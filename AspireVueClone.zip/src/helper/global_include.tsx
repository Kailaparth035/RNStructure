import Color from './app_colors';
import Assets from './app_image';
import ScreenName from './app_contants';

export const GlobalInclude = {
  //theme
  Color: Color,
  Assets: Assets,
  ScreenName: ScreenName,
};
